export const jwtConstants = {
  // !! SECURITY WARNING !!
  // This is a fallback secret key and SHOULD NOT be used in production.
  // ALWAYS set a strong, unique JWT_SECRET in your environment variables.
  // Generate one using: openssl rand -hex 32
  secret: 'CHANGE_THIS_DEFAULT_SECRET_KEY_IN_ENV',
  expiresIn: '3600s', // Default expiration time (1 hour)
};

