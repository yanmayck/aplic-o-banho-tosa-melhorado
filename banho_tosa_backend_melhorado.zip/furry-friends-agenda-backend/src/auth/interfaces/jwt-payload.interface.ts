export interface JwtPayload {
  userId: string;
  username: string;
  roles: string[];
}
