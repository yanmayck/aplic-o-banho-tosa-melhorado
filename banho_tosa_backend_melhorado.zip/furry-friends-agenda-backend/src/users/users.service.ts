import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger, // Import Logger
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { User, Prisma } from '@prisma/client';
import * as bcrypt from 'bcrypt';

// Consider moving this to a configuration file or environment variable
export const roundsOfHashing = parseInt(process.env.BCRYPT_SALT_ROUNDS || '10', 10);

@Injectable()
export class UsersService {
  // Initialize Logger
  private readonly logger = new Logger(UsersService.name);

  constructor(private prisma: PrismaService) {}

  async createUser(data: Prisma.UserCreateInput): Promise<User> {
    this.logger.log(`Attempting to create user with email: ${data.email}`);
    const existingUser = await this.prisma.user.findUnique({
      where: { email: data.email },
    });

    if (existingUser) {
      this.logger.warn(`User creation failed: Email ${data.email} already exists.`);
      throw new ConflictException('User with this email already exists');
    }

    try {
      const hashedPassword = await bcrypt.hash(data.password, roundsOfHashing);
      const newUser = await this.prisma.user.create({
        data: {
          ...data,
          password: hashedPassword,
        },
      });
      this.logger.log(`User created successfully with ID: ${newUser.id}`);
      return newUser;
    } catch (error) {
      this.logger.error(`Failed to create user ${data.email}`, error.stack);
      // Handle potential Prisma errors during creation if necessary
      throw error; // Re-throw the original error or a more specific one
    }
  }

  async findOneById(id: string): Promise<User | null> {
    this.logger.log(`Finding user by ID: ${id}`);
    const user = await this.prisma.user.findUnique({ where: { id } });
    if (!user) {
      this.logger.warn(`User with ID "${id}" not found.`);
      // Returning null is often preferred in service layers, especially for auth checks,
      // to allow the caller (e.g., AuthService) to handle the "not found" case specifically.
      // Throwing NotFoundException here would make it harder for AuthService to distinguish
      // between 'user not found' and 'password incorrect' during login.
      return null;
    }
    return user;
  }

  async findOneByEmail(email: string): Promise<User | null> {
    this.logger.log(`Finding user by email: ${email}`);
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user) {
      this.logger.warn(`User with email "${email}" not found.`);
      // See comment in findOneById regarding returning null vs. throwing NotFoundException.
      return null;
    }
    return user;
  }

  async updateUser(
    id: string,
    data: Prisma.UserUpdateInput,
  ): Promise<User | null> {
    this.logger.log(`Attempting to update user with ID: ${id}`);
    // Ensure password is not updated directly through this method if present in data
    // Password updates should ideally have a separate, dedicated flow.
    if (data.password) {
      this.logger.warn(`Attempted to update password via general updateUser method for user ID: ${id}. This is not allowed.`);
      // Optionally throw an error or simply remove the password field
      delete data.password;
      // Or throw new BadRequestException('Password updates should use a dedicated endpoint.');
    }

    try {
      const user = await this.prisma.user.update({
        where: { id },
        data,
      });
      this.logger.log(`User updated successfully: ${id}`);
      return user;
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === 'P2025' // Prisma's code for 'Record to update not found.'
      ) {
        this.logger.warn(`User update failed: User with ID "${id}" not found.`);
        throw new NotFoundException(`User with ID "${id}" not found`);
      }
      this.logger.error(`Failed to update user ${id}`, error.stack);
      throw error; // Re-throw other errors
    }
  }

  // Consider adding a dedicated method for password updates
  // async updateUserPassword(id: string, newPassword: string): Promise<void> { ... }

  // Consider adding deleteUser method
  // async deleteUser(id: string): Promise<User | null> { ... }
}

